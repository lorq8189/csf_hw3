# csf_hw3
# Team Members: Joanna Cheng, Lucas Orquiza



Commands and stuff to copy:

rm -f solution.zip
zip -9r solution.zip Makefile *.h *.cpp README.txt