#ifndef CSIM_FUNCS_H
#define CSIM_FUNCS_H

bool powerTwo (int x);



#endif